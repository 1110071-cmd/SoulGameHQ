# SoulsGameHQ（高畫質版）— 一鍵雲端打包 Windows EXE

這個專案已設定好 **AppVeyor**，讓你不用安裝任何東西，就能在雲端自動打包出 Windows 安裝檔。

---

## 你要做的事（超簡單）
1. **建立 GitHub 專案**
   - 登入 https://github.com → 右上角「+」→ New repository
   - Repository name: `SoulsGameHQ`
   - 可選 Public → Create repository
   - 在新倉庫頁面，找到 **"uploading an existing file"** → 直接把本 ZIP 解壓後的所有檔案 **全選拖進去** 上傳
   - 填 Commit message → **Commit changes**

2. **啟用 AppVeyor 並連結 GitHub**
   - 進入 https://www.appveyor.com/ → 使用 GitHub 帳號登入
   - 登入後點「New Project」→ 選 GitHub → 找到你的 `SoulsGameHQ` 倉庫 → 點 **Add**
   - 在專案頁按 **New build**（或它會自動開始第一次建置）

3. **下載 Windows 安裝檔**
   - 等待 Build 完成後，切到 **Artifacts** 分頁
   - 下載 `SoulsGameHQ_Windows_Installer` 裡的 `.exe`（例如 `SoulsGameHQ Setup 1.0.xxx.exe`）

4. **安裝與啟動**
   - 在 Windows 雙擊 `.exe` → 如被防護警告，點「更多資訊」→「仍要執行」
   - 安裝完成後桌面會有捷徑，雙擊即可開始遊戲

---

## 常見問題（FAQ）
- **Build 失敗**：
  - 重試一次；若 `npm install` 失敗，請確保倉庫是 Public 或 AppVeyor 能存取，並稍候再試（AppVeyor 有時候會短暫性故障）。
- **離線執行**：
  - `index.html` 目前使用 CDN 載入 Three.js，首次啟動建議保持網路暢通；若要完全離線，請將 three.min.js 下載到 `assets/` 並把 `<script>` 改成本地路徑。
- **加入更高畫質的 3D 模型**：
  - 把 `.glb` 檔放到 `assets/models/`，並在 `index.html` 中自行載入（目前程式使用程序幾何，已可直接遊玩）。

---

## 開發腳本（如需本機測試）
```bash
npm install
npm start          # 開發模式
npm run build-win  # 直接在本機打包（需安裝 Windows 環境）
```
