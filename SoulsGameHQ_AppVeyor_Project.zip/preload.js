// Minimal preload - keeps node integration off for security
window.addEventListener('DOMContentLoaded', () => {
  window.electronLog = (msg) => { console.log('[electron]', msg); };
});
